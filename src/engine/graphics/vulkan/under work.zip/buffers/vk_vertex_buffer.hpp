#pragma once

#include "engine/graphics/vulkan/vk_logical_device.hpp"
#include "engine/graphics/vertexData.hpp"



namespace oe::graphics {

	class VertexBuffer {
	public:
		vk::Buffer m_vertex_buffer;
		vk::DeviceMemory m_vertex_buffer_memory;

		size_t m_size;
		void* mapped_buffer;

		const LogicalDevice* m_logical_device;

	public:
		VertexBuffer(vk::BufferUsageFlagBits usage, size_t size, const LogicalDevice* logical_device);
		~VertexBuffer();

		void map();
		void unmap();
		void submit(const VertexData& vertex_data);

	private:
		uint32_t findMemoryType(uint32_t typeFilter, vk::MemoryPropertyFlags properties);

	};

}