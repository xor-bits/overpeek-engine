#include "vk_frame_buffer.hpp"



namespace oe::graphics {

	FrameBuffer::FrameBuffer(vk::Image m_image) {

	}

	FrameBuffer::FrameBuffer(const glm::vec2& size) {

	}

	FrameBuffer::~FrameBuffer() {

	}

}