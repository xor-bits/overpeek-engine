#include "database.h"

Database::Item Database::items[COUNT_ITEMS];
Database::Tile Database::tiles[COUNT_TILES];
Database::Object Database::objects[COUNT_OBJECTS];
Database::Creature Database::creatures[COUNT_CREATURES];
Database::Biome Database::biomes[COUNT_BIOMES];