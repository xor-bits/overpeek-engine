#include "logic/game.h"

Game game;

//int WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow) {
int main() {
	game.init();
	game.close();
}